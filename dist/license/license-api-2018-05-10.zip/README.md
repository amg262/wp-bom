# License API

Simple API for generating and validation of license key.
You can simply secure your web application against inlegal copy.

